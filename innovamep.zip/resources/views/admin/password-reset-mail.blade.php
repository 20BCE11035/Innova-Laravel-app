<html>
    <body>
    <a href="{{route('reset.password', $code)}}"><u>Reset Password</u></a>
    </body>
</html>