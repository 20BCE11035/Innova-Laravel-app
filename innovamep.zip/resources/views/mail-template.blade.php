<html>
    <body>
        <p>{{$senderMessage}}</p>
    </body>
</html>