<?php $__env->startSection('content'); ?>

    <div class="sidenav">
        <div class="login-main-text">
            <h2>Admin<br> Login Page</h2>
            <p>Login or register from here to access.</p>
        </div>
    </div>
    <div class="main">
        <div class="col-md-6 col-sm-12">
            <div class="login-form">
                <?php if(session()->has('error')): ?>
                    <p class="alert alert-danger text-danger"><?php echo e(session()->get('error')); ?></p>
                <?php endif; ?>

                <?php if(session()->has('success')): ?>
                    <p class="alert alert-success text-success"><?php echo e(session()->get('success')); ?></p>
                <?php endif; ?>

                <form action="<?php echo e(route('login.post')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Email</label>
                        <input name="email" type="email" class="form-control" placeholder="User Name" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input name="password" type="password" class="form-control" placeholder="Password" required>
                    </div>
                    <button type="submit" class="btn btn-black">Login</button>
                    <a href="<?php echo e(route('password.reset')); ?>"> Forgot Password? </a>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.outer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laragon\www\innovamep\resources\views/admin/login.blade.php ENDPATH**/ ?>