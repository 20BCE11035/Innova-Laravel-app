<?php $__env->startSection('content'); ?>
    <div class="form-gap"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                            <h3><i class="fa fa-lock fa-4x"></i></h3>
                            <h2 class="text-center">Forgot Password?</h2>
                            <p>You can reset your password here.</p>
                            <div class="panel-body">
                                <?php if(isset($error)): ?>
                                    <p class="alert alert-danger text-danger"><?php echo e($error); ?></p>
                                <?php endif; ?>

                                <?php if(isset($success)): ?>
                                    <p class="alert alert-success text-success"><?php echo e($success); ?></p>
                                <?php endif; ?>
                                <form action="<?php echo e(route('password.reset.post')); ?>" id="register-form" role="form" autocomplete="off" class="form" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                            <input id="email" name="email" placeholder="Email Address" class="form-control"  type="email" required>
                                        </div>
                                    </div>
                                    <div class="form-group d-flex">
                                        <input id="send-reset-email" class="btn btn-lg btn-primary btn-block" value="Reset Password" type="submit">
                                        <div class="float-right mt-2 ml-2" id="loading">
                                            <div class="spinner-border text-info"  role="status"></div>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.outer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laragon\www\innovamep\resources\views/admin/password-reset.blade.php ENDPATH**/ ?>