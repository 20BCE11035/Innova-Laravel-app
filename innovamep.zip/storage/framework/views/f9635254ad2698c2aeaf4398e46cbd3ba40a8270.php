<?php $__env->startSection('content'); ?>
    <div class="form-gap"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                            <h3><i class="fa fa-lock fa-4x"></i></h3>
                            <h2 class="text-center">Reset Password</h2>
                            <hr>
                            <div class="panel-body">
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-warning">
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                <?php endif; ?>

                                <form action="<?php echo e(route('reset.password.post', $code)); ?>" id="register-form" role="form" autocomplete="off" class="form" method="post">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                            <input id="email" name="password" placeholder="New Password" class="form-control"  type="password" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                            <input id="email" name="confirm_password" placeholder="Confirm Password" class="form-control"  type="password" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <input class="btn btn-lg btn-primary btn-block" value="Confirm" type="submit">
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.outer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laragon\www\innovamep\resources\views/admin/confirm-password.blade.php ENDPATH**/ ?>