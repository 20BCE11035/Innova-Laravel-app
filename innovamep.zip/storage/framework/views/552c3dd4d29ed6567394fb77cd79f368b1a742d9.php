<?php $__env->startSection('content'); ?>

    <h1>This is Dashboard</h1>
    <h2>Upload Pdf</h2>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>

    <?php elseif(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('upload.pdf')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(@csrf_field()); ?>

        <label for="myfile">Select a file:</label>
        <input type="file" id="myfile" name="myfile"><br><br>
        <input type="submit">
    </form>

    <a class="btn btn-danger mt-5" href="<?php echo e(route('logout')); ?>">Logout</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laragon\www\innova\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>